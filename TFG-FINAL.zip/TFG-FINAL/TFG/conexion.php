<?php
	
	$mysqli = new mysqli("localhost", "root", "", "r_user");
	
?>
