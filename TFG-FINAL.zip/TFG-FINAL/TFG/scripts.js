function iniciarMap() {
    var options = {
        center: { lat: YOUR_LATITUDE, lng: YOUR_LONGITUDE },
        zoom: 10
    };
    var map = new google.maps.Map(document.getElementById('map'), options);
}

// Load the map when the Google Maps API is loaded
google.maps.event.addDomListener(window, 'load', iniciarMap);